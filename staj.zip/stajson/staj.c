#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct ogrenci {         //struct : Birbirleriyle ili?kili degiskenlerin, bir isim altynda toplanmasini saglar
    	char *isim[50];
     	char *soyisim[50];
 		char *bolum[50];
 		int *ogrenciNo;
		
}ogrenciler[100]; 
struct Firmalar{
		char *FirmaAd[25];
		char *FaaliyetAlani[25];
		char *MerkezSehir[25];
		char *Telefon[20];                             //musteri eklemek icin
		int *VergiNo;
		
		
}Firmalar[100];
struct Stajer{
	int *VergiNo;
	int *ogrenciNo;
	char *baslangic[15];
	char *bitis[15];
	char *tur[15];
}Stajlar[100];

char baslangicT[20];
char bitisT[20];
int menu(){
	system("CLS");
printf(" \t \t*********************\n");
printf(" \t \t                                                      \n");
printf(" \t \t                                                     \n");
printf(" \t \t                                                    \n");
printf(" \t \t                   - HOSGELDINIZ-                     \n");
printf(" \t \t   *             EKLEME ISLEMLERI ICIN            {1}*\n");
printf(" \t \t   *          GORUNTULEME ISLEMLERI  ICIN         {2}*\n");
printf(" \t \t   *           GUNCELLEME ISLEMLERI ICIN          {3}*\n");
printf(" \t \t   *            SILME ISLEMLERI ICIN              {4}*\n");
printf(" \t \t   *             STAJ LISTELEME ICIN              {5}*\n");
printf(" \t \t   *             STAJ EKLEME ICIN                 {6}*\n"); //menu kismi fonksiyon haline getirip mainde cagiriliyor
printf(" \t \t   *        		CIKMAK ICIN						{0}*\n");
printf(" \t \t                                                    \n");
printf(" \t \t                                                     \n");
printf(" \t \t *******************\n");
int menuSecim;

return menuSecim;
}
void FirmaEkleme() {
	FILE *_dosya;
	int FirmaVergiNo=0;
	if((_dosya=fopen("firmaKayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
		int i=0;
	

		

				while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 				fscanf(_dosya,"%s%s%s%s%d",Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, &Firmalar[i].VergiNo);
 					if(Firmalar[i].VergiNo ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
					break;
				}
 			
				i++;
			 }
				 
				printf(" Firma Adi: ");
				scanf("%s",Firmalar[i].FirmaAd);
				printf("\n Firmanin faaliyet alani : ");
				scanf("%s",Firmalar[i].FaaliyetAlani);
				printf("\n Firmanin merkez sehri neresidir : ");
				scanf("%s",Firmalar[i].MerkezSehir);
				printf("\nTelefon no:  ");                      //console dan bilgiler alinir
				scanf("%s",Firmalar[i].Telefon);
				Vergi:
				printf("\n Firmanin vergi numarasini yaziniz : ");
				scanf("%d",&FirmaVergiNo);
				
				if(FirmaVergiNoKontrol(FirmaVergiNo)==0){
					printf("\n Yazmis oldugunuz firma numarasi baska bir firma tarafindan kullanilmaktadir. tekrar giriniz : ");
					goto Vergi;	
				}
				else{
					Firmalar[i].VergiNo=FirmaVergiNo;
				}
				

				fprintf(_dosya,"%s %s %s %s %d \n",Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, Firmalar[i].VergiNo);  //acik dosya uzerine  yazdirma
			FirmaListele();    //totaldeki butun musterileri cagirmak icin
			fclose(_dosya);         //fopenlanan her dosya kapatilmalidir
	}
}
void DosyayaFirmaTekrarYazdir(){   // g�ncelleme i�in yeni girilen bilgileri tekrar yazd�r�r
	FILE *_dosya;
	if((_dosya=fopen("firmaKayit.txt","w+")) == NULL){
			printf("Dosya olusturulamadi");
	}else {
			fprintf(_dosya,""); // t�m verileri siler
			fclose(_dosya);
	}
	if((_dosya=fopen("firmaKayit.txt","a+")) == NULL){
			printf("Dosya olusturulamadi");
	}else {
		int i = 0;
		while(1){
			if(Firmalar[i].VergiNo ==0){
				break;
			}
			fprintf(_dosya,"%s %s %s %s %d \n",Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, Firmalar[i].VergiNo);  //acik dosya uzerine  yazdirma
			i++; // tek tek tekrar yazd�r�r
			
		}
		fclose(_dosya);
	}
}

void FirmaDuzenle(){ // firma bilgilerini d�zenlemek i�in
	int VergiNo=0;
	int i =0;
	int indexTutucu=0;
	int girdiMi = 0;
	FirmalariDoldur();
	printf("\nGuncellemek istediginiz Firmanin Vergi numarasini giriniz :");
	scanf("%d",&VergiNo);
	while(1){
		if(Firmalar[i].VergiNo ==0){
			break;
		}
		if(Firmalar[i].VergiNo == VergiNo){
			girdiMi = 1;
			indexTutucu = i; // d�zenlenecek bilginin indexini tutar
		}
		i++;
	}
	if(girdiMi == 0){
		printf("Sistemde kayitli boyle firma bulunmamaktadir");
	}else {
		int secim = 0;
		printf("\n\t%-14s| %-18s | %-10s | %-12s | %-12s |\n", " FIRMA ADI", "  FAALIYET ALANI", " MERKEZ SEHIR", " TELEFON", " VERGI NO");
		printf("\t %-17s  %-19s  %-14s  %-13s  %-12d \n" ,Firmalar[indexTutucu].FirmaAd,Firmalar[indexTutucu].FaaliyetAlani ,Firmalar[indexTutucu].MerkezSehir,Firmalar[indexTutucu].Telefon, Firmalar[indexTutucu].VergiNo);		
		printf("\n Duzenlemek istediginiz bilgiyi seciniz: 1:firma ismi \n 2:firma faaliyet alani \n 3:Merkez sehri \n 4:Telefonu \n");
		scanf("%d",&secim);
		switch(secim){
			case 1:
				printf("Firmanin yeni ismini giriniz. \n");
				scanf("%s",Firmalar[indexTutucu].FirmaAd);
				printf("Firma basariyla guncellenmistir. \n");
				DosyayaFirmaTekrarYazdir();
		    	FirmaListele();
				break;
			case 2:
				printf("Firmanin yeni Faaliyet alanini giriniz :\n");
				scanf("%s",Firmalar[indexTutucu].FaaliyetAlani);
				printf("Firma basariyla guncellenmistir.\n");
				DosyayaFirmaTekrarYazdir();
				FirmaListele();
				break;
			case 3:
				printf("Firmanin yeni merkez sehrini giriniz :\n");
				scanf("%s",Firmalar[indexTutucu].MerkezSehir);
				printf("Firma basariyla guncellenmistir.\n");
				DosyayaFirmaTekrarYazdir();
				FirmaListele();
				break;
			case 4:
				printf("Firmanin yeni telefonunu giriniz :\n");
				scanf("%s",Firmalar[indexTutucu].Telefon);
				printf("Firma basariyla guncellenmistir.\n");
				DosyayaFirmaTekrarYazdir();
				FirmaListele();
				break;
			default:
				printf("Firmanin bilgileri disinda bir bilgiyi guncellemek istiyorsunuz.");
		}
	}

	
	
}
int FirmaVergiNoKontrol(int VergiNo){ // girilen verginin veritaban�nda olup olmad���n� kontrol eder
	FirmalariDoldur();
	int i =0;
	int girdiMi =1;
	while(1){
		if(Firmalar[i].VergiNo ==0){
			break;
		}
		if(Firmalar[i].VergiNo == VergiNo){
			girdiMi =0;
			break;
		}
		i++;
	}
	return girdiMi;
}
void FirmalariDoldur() {   //dosyadaki musterileri arraye aktarir
		FILE *_dosya;
		if((_dosya=fopen("firmaKayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else {
		int i=0;
				while( !feof(_dosya) ){
 					fscanf(_dosya,"%s%s%s%s%d",Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, &Firmalar[i].VergiNo);
 					if(Firmalar[i].VergiNo ==0) {  //bittigini gosterir
					break;					
				}
				i++;
			 }	
			fclose(_dosya);
	}
}
void FirmaSilme(){ // firma d�zenleme gibi �al���yor
	int VergiNo=0;
	int i =0;
	int indexTutucu=0;
	int girdiMi = 0;
	FirmalariDoldur();
	printf("\n Silinmesini istediginiz Firmanin vergi numarasini yaziniz :  ");
	scanf("%d",&VergiNo);
	while(1){
		if(Firmalar[i].VergiNo ==0){
			break;
		}
		if(Firmalar[i].VergiNo == VergiNo){
			girdiMi = 1;
			indexTutucu = i;
		}
		i++;
	}
	if(girdiMi == 0){
		printf("Aradiginiz firma sistemde bulunamadi..");
	}else {
		int i =indexTutucu;
		while(1){
			if(Firmalar[i].VergiNo == 0){
				break;
			}
			strcpy(Firmalar[i].FirmaAd,Firmalar[i+1].FirmaAd);  // sa�daki stringi sola aktar�r
			strcpy(Firmalar[i].FaaliyetAlani,Firmalar[i+1].FaaliyetAlani);
			strcpy(Firmalar[i].MerkezSehir,Firmalar[i+1].MerkezSehir);
			strcpy(Firmalar[i].Telefon,Firmalar[i+1].Telefon);
			Firmalar[i].VergiNo =  Firmalar[i+1].VergiNo;
			i++;
		}
		DosyayaFirmaTekrarYazdir();
		FirmaListele();
	}
}
void FirmaListele() {  //case 4 urunleri sirasi ile goruntuler
		FILE *_dosya;
			
		if((_dosya=fopen("firmaKayit.txt","r+")) == NULL) {
		printf("\nDosya olusturulamadi \n");
	}else {
		int i=0;
		
			printf("\n\t     | %-14s| %-18s | %-10s | %-12s | %-12s |\n", " FIRMA ADI", "  FAALIYET ALANI", " MERKEZ SEHIR", " TELEFON", " VERGI NO"); //%-12s : tabloda degerleri hizalamayi saglar
			printf("\t*************************** \n");  //tablo duzenleme amacli
				while( !feof(_dosya) ){
			
 			fscanf(_dosya,"%s%s%s%s%d",Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, &Firmalar[i].VergiNo);
 			
 					
 					if(Firmalar[i].VergiNo ==0) {
					break;		
					//urunFonkCalis=1;			
				}
					printf("\t %-3d. %-14s  %-19s  %-14s  %-13s  %-12d \n",(i+1) ,Firmalar[i].FirmaAd,Firmalar[i].FaaliyetAlani ,Firmalar[i].MerkezSehir,Firmalar[i].Telefon, Firmalar[i].VergiNo);
					printf("\t------------------------------------------------------------------------------- \n");
					i++;
			 }	
			 	
			fclose(_dosya);
	}
}
void OgrenciEkle(){
	FILE *_dosya;
	if((_dosya=fopen("ogrencikayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
				int i =0;
				int ogrenciNo =0;
				while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 				fscanf(_dosya,"%s%s%s%d",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum, &ogrenciler[i].ogrenciNo);
 					if(ogrenciler[i].ogrenciNo ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
					break;
				}
				i++;
 			
			 }
				printf("Adiniz: ");
				scanf("%s",ogrenciler[i].isim);
				printf("\nSoyadiniz:  ");
				scanf("%s",ogrenciler[i].soyisim);
				printf("\n Bolum:  ");                      
				scanf("%s",ogrenciler[i].bolum);
				printf("\n OgrenciNo:  ");                      
				scanf("%d",&ogrenciNo);
				if(OgrenciNoKontrol(ogrenciNo)== 1){
						ogrenciler[i].ogrenciNo = ogrenciNo;
						fprintf(_dosya,"%s %s %s %d\n",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum, ogrenciler[i].ogrenciNo);  //acik dosya uzerine  yazdirma
				}
				else {
					printf("Ogrenci zaten mevcut");
				}
			OgrencileriListele();
			fclose(_dosya);         //fopenlanan her dosya kapatilmalidir
	}
}

int OgrenciNoKontrol(int ogrenciNo){
	OgrencileriDoldur();
	int i =0;
	int girdiMi =1;
	while(1){
		if(ogrenciler[i].ogrenciNo ==0){
			break;
		}
		if(ogrenciler[i].ogrenciNo == ogrenciNo){
			girdiMi =0;
			break;
		}
		i++;
	}
	return girdiMi;
}
void OgrenciDuzenle(){
	int ogrenciNo=0;
	int i =0;
	int indexTutucu=0;
	int girdiMi = 0;
	OgrencileriDoldur();
	printf("\nOgrenci numarasy gir:");
	scanf("%d",&ogrenciNo);
	while(1){
		if(ogrenciler[i].ogrenciNo ==0){
			break;
		}
		if(ogrenciler[i].ogrenciNo == ogrenciNo){
			girdiMi = 1;
			indexTutucu = i;
		}
		i++;
	}
	if(girdiMi == 0){
		printf("Ogrenci bulunamady");
	}else {
		int secim = 0;
		printf("\n%-10s | %-10s | %-10s\n", "Isim" ,"Soyisim ", "Bolum" );
		printf("\n%-10s   %-10s   %-10s\n",ogrenciler[indexTutucu].isim,ogrenciler[indexTutucu].soyisim,ogrenciler[indexTutucu].bolum);
		printf("\n1-Isim");
		printf("\n2-Soyisim");
		printf("\n3-Bolum");
		printf("\nDegistirmek istediginiz bilgiyi seciniz\n");
		scanf("%d",&secim);
		switch(secim){
			case 1:
				printf("Yeni isim giriniz.");
				scanf("%s",ogrenciler[indexTutucu].isim);
				DosyayaOgrenciTekrarYazdir();
				OgrencileriListele();
				break;
			case 2:
				printf("Yeni soyisim giriniz.");
				scanf("%s",ogrenciler[indexTutucu].soyisim);
				DosyayaOgrenciTekrarYazdir();
				OgrencileriListele();
				break;
			case 3:
				printf("Yeni bolum giriniz.");
				scanf("%s",ogrenciler[indexTutucu].bolum);
				DosyayaOgrenciTekrarYazdir();
				OgrencileriListele();
				break;
			default:
				printf("Hataly giri?");
		}
	}
}
void DosyayaOgrenciTekrarYazdir(){
	FILE *_dosya;
	if((_dosya=fopen("ogrencikayit.txt","w+")) == NULL){
			printf("Dosya olusturulamadi");
	}else {
			fprintf(_dosya,"");
			fclose(_dosya);
	}
	if((_dosya=fopen("ogrencikayit.txt","a+")) == NULL){
			printf("Dosya olusturulamadi");
	}else {
		int i = 0;
		while(1){
			if(ogrenciler[i].ogrenciNo ==0){
				break;
			}
			fprintf(_dosya,"%s %s %s %d\n",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum, ogrenciler[i].ogrenciNo);  //acik dosya uzerine  yazdirma
			i++;
			
		}
		fclose(_dosya);
	}
}
void OgrenciSil(){
	int ogrenciNo=0;
	int i =0;
	int indexTutucu=0;
	int girdiMi = 0;
	OgrencileriDoldur();
	printf("\nOgrenci numarasy gir:");
	scanf("%d",&ogrenciNo);
	while(1){
		if(ogrenciler[i].ogrenciNo ==0){
			break;
		}
		if(ogrenciler[i].ogrenciNo == ogrenciNo){
			girdiMi = 1;
			indexTutucu = i;
		}
		i++;
	}
	if(girdiMi == 0){
		printf("Ogrenci bulunamady");
	}else {
		int i =indexTutucu;
		while(1){
			if(ogrenciler[i].ogrenciNo == 0){
				break;
			}
			strcpy(ogrenciler[i].isim,ogrenciler[i+1].isim); 
			strcpy(ogrenciler[i].soyisim,ogrenciler[i+1].soyisim);
			strcpy(ogrenciler[i].bolum,ogrenciler[i+1].bolum);
			ogrenciler[i].ogrenciNo =  ogrenciler[i+1].ogrenciNo;
			i++;
		}
		DosyayaOgrenciTekrarYazdir();
		OgrencileriListele();
	}
}
void OgrencileriDoldur(){
	FILE *_dosya;
	if((_dosya=fopen("ogrencikayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
				int i =0;
				while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 				fscanf(_dosya,"%s%s%s%d",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum, &ogrenciler[i].ogrenciNo);
 					if(ogrenciler[i].ogrenciNo ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
					break;
				}
				i++;
			 }
		}
			fclose(_dosya);
}
void OgrencileriListele(){
	OgrencileriDoldur();
	int i =0;
	printf("\n%-10s | %-10s | %-10s | %-10s \n", "Isim" ,"Soyisim ", "Bolum", "Ogrenci No" );
	while(1){
		if(ogrenciler[i].ogrenciNo ==0){
			break;
		}
		
		printf("\n%-10s   %-10s   %-10s   %-10d   ",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum,ogrenciler[i].ogrenciNo);
		i++;
	}
}

void StajEkle(){ // ��renci firma ekleme gibi �al���yor
		FILE *_dosya;
	int FirmaVergiNo=0;
	if((_dosya=fopen("stajKayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
		int i=0;
				while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 				fscanf(_dosya,"%d%d%s%s%s",&Stajlar[i].ogrenciNo,&Stajlar[i].VergiNo ,Stajlar[i].baslangic,Stajlar[i].bitis, Stajlar[i].tur);
 					if(Stajlar[i].VergiNo ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
					break;
				}
 			
				i++;
			 }
				 
				printf(" Ogrenci No: ");
				scanf("%d",&Stajlar[i].ogrenciNo);			
				printf("\n Firma Verigi No : ");
				scanf("%d",&Stajlar[i].VergiNo);
				printf("\n Baslangyc Tarihi:  ");
				scanf("%s",Stajlar[i].baslangic);
				printf("\nBitis Tarihi:  ");                      //console dan bilgiler alinir
				scanf("%s",Stajlar[i].bitis);
				printf("\nStaj Turu:  ");                      //console dan bilgiler alinir
				scanf("%s",Stajlar[i].tur);

				
				if(FirmaVergiNoKontrol(Stajlar[i].VergiNo)==0 && OgrenciNoKontrol(Stajlar[i].ogrenciNo)==0){
					fprintf(_dosya,"%d %d %s %s %s \n",Stajlar[i].ogrenciNo,Stajlar[i].VergiNo ,Stajlar[i].baslangic,Stajlar[i].bitis, Stajlar[i].tur);  //acik dosya uzerine  yazdirma
					TarihHesapla(Stajlar[i].baslangic,Stajlar[i].bitis);		
				}
				else{
						printf("Ogrenci ya da firma bulunamady");
				}
			fclose(_dosya);         //fopenlanan her dosya kapatilmalidir
	}
}
void StajDoldur(){ // txt dosyas�ndak� bilgileri arraye aktar�r
	FILE *_dosya;
	int i=0;
		if((_dosya=fopen("stajKayit.txt","a+")) == NULL) {   //dosya islemlerinde fopen dosya i�inde islem yapmak icin kullanilir a+ ise hem olusturma,okuma,yazma her islem yapilabilir
		printf("Dosya olusturulamadi");
	}else {
		while( !feof(_dosya) ){   //dosya tamamen okunadugunda while sona erir
			
 		fscanf(_dosya,"%d%d%s%s%s",&Stajlar[i].ogrenciNo,&Stajlar[i].VergiNo ,Stajlar[i].baslangic,Stajlar[i].bitis, Stajlar[i].tur);
 			if(Stajlar[i].VergiNo ==0) {   //dosya icerisindeki bilgileri alir ve bittiginde break(durdurma)saglanir
				break;
		}
 			
			i++;
			}
			fclose(_dosya);  
		}
		       
}
void TamamlanmisStaj(){ 
	StajDoldur();
	int donanimHafta=0;
	int yazilimHafta =0;
	int i =0;
	int k = 0;
	int m =0;
	int toplam =0;
	printf("\n Tamamlanmis Stajlar\n");
		for( k = 0 ; k<=200 ; k++){ // ikili ofor i�erisinde tek tek verileri dola��r ve kar��la�t�r�r
			if(Stajlar[k].ogrenciNo !=0){
					if(!strcmp(Stajlar[k].tur,"Donanim")){
						donanimHafta = TarihHesapla(Stajlar[k].baslangic,Stajlar[k].bitis)/7;
					
			}
			else if(!strcmp(Stajlar[k].tur,"Yazilim")){
			yazilimHafta = TarihHesapla(Stajlar[k].baslangic,Stajlar[k].bitis)/7;
			
				}
		
			for(m = k+1 ;m<=2500;m++){
				if(Stajlar[m].ogrenciNo !=0){
					if(!strcmp(Stajlar[m].tur,"Donanim") && Stajlar[m].ogrenciNo ==Stajlar[k].ogrenciNo ){
						donanimHafta = TarihHesapla(Stajlar[m].baslangic,Stajlar[m].bitis)/7;
					
							 toplam = yazilimHafta + donanimHafta;
							//printf("Toplam %d %d",Stajlar[k].ogrenciNo,toplam);
							if(toplam >=12){
								if(yazilimHafta>=4 && donanimHafta>=2){
										//printf("\nD %d %d hafta ",Stajlar[m].ogrenciNo,donanimHafta);
										//printf("\nY1 %d %d hafta ",Stajlar[k].ogrenciNo,yazilimHafta);
								}
							}
					}
					else if(!strcmp(Stajlar[m].tur,"Yazilim")&& Stajlar[m].ogrenciNo ==Stajlar[k].ogrenciNo){
						yazilimHafta = TarihHesapla(Stajlar[m].baslangic,Stajlar[m].bitis)/7;
							 toplam = yazilimHafta + donanimHafta;
							//printf("Toplam %d %d",Stajlar[k].ogrenciNo,toplam);
								if(toplam >=12){
								if(yazilimHafta>=4 && donanimHafta>=2){
									//	printf("\nD %d %d hafta ",Stajlar[m].ogrenciNo,donanimHafta);
									//	printf("\nY1 %d %d hafta ",Stajlar[k].ogrenciNo,yazilimHafta);
										OgrenciYazdir(Stajlar[m].ogrenciNo);
								}
							}
						}
						
					}
				}
			
				}
			}
}
void TamamlanmamisStaj(){ //ayni mantik cal�s�r
	StajDoldur();
	int donanimHafta=0;
	int yazilimHafta =0;
	int i =0;
	int k = 0;
	int m =0;
	int toplam =0;
		printf("\n Tamamlanmamis Stajlar\n");
		for( k = 0 ; k<=200 ; k++){
			if(Stajlar[k].ogrenciNo !=0){
					if(!strcmp(Stajlar[k].tur,"Donanim")){
						donanimHafta = TarihHesapla(Stajlar[k].baslangic,Stajlar[k].bitis)/7;
					
			}
			else if(!strcmp(Stajlar[k].tur,"Yazilim")){
			yazilimHafta = TarihHesapla(Stajlar[k].baslangic,Stajlar[k].bitis)/7;
			
				}
		
			for(m = k+1 ;m<=200;m++){
				if(Stajlar[m].ogrenciNo !=0){
					if(!strcmp(Stajlar[m].tur,"Donanim") && Stajlar[m].ogrenciNo ==Stajlar[k].ogrenciNo ){
						donanimHafta = TarihHesapla(Stajlar[m].baslangic,Stajlar[m].bitis)/7;
					
							 toplam = yazilimHafta + donanimHafta;
							//printf("Toplam %d %d",Stajlar[k].ogrenciNo,toplam);
							if(toplam <=12){
								if(yazilimHafta<=4 || donanimHafta<=2){
										//printf("\nD %d %d hafta ",Stajlar[m].ogrenciNo,donanimHafta);
										//printf("\nY1 %d %d hafta ",Stajlar[k].ogrenciNo,yazilimHafta);
										OgrenciYazdir(Stajlar[m].ogrenciNo);
								}
							}
					}
					else if(!strcmp(Stajlar[m].tur,"Yazilim")&& Stajlar[m].ogrenciNo ==Stajlar[k].ogrenciNo){
						yazilimHafta = TarihHesapla(Stajlar[m].baslangic,Stajlar[m].bitis)/7;
							 toplam = yazilimHafta + donanimHafta;
							//printf("Toplam %d %d",Stajlar[k].ogrenciNo,toplam);
								if(toplam <=12){
								if(yazilimHafta<=4 || donanimHafta<=2){
									//	printf("\nD %d %d hafta ",Stajlar[m].ogrenciNo,donanimHafta);
									//	printf("\nY1 %d %d hafta ",Stajlar[k].ogrenciNo,yazilimHafta);
										OgrenciYazdir(Stajlar[m].ogrenciNo);
								}
							}
						}
						
					}
				}
			
				}
			}
}
void OgrenciYazdir(int OgrenciNo){  // parametre ile g�nderilen ogrenci numaras�n� bulur ekrana yazd�r�r
	OgrencileriDoldur();
	int i = 0;
	while(ogrenciler[i].ogrenciNo != 0){
		if(ogrenciler[i].ogrenciNo ==OgrenciNo ){
			printf("\n%-10s   %-10s   %-10s   %-10d   ",ogrenciler[i].isim,ogrenciler[i].soyisim,ogrenciler[i].bolum,ogrenciler[i].ogrenciNo);
		}
		i++;
	}
}
int TarihHesapla(char baslangicx[] , char bitisy[]){ // girilen tarihleri g�ne �evirir
	
	strcpy(baslangicT,baslangicx);
	strcpy(bitisT,bitisy);
	
    int m = 0;
    int i;
    char *p = strtok (baslangicT, "/"); //  
    char *baslangic[3];

    while (p != NULL) // her slashta char arrayini par�alar
    {
        baslangic[m++] = p;
        p = strtok (NULL, "/");
    }
    int j =0;
    char *k = strtok (bitisT, "/");
    char *bitis[3];
    while (k != NULL)
   {
        bitis[j++] = k;
        k = strtok (NULL, "/");
      
    }
   
   	int yillikfark = (atoi(bitis[2])-atoi(baslangic[2])); // char arrayindeki say�y� integer a �evirir
   	int aylikfark =  (atoi(bitis[1])-atoi(baslangic[1]));
   	int gunlukfark =  (atoi(bitis[0])-atoi(baslangic[0]));
   	if(gunlukfark <0){
   			gunlukfark +=30;
   			aylikfark--;
	   }
	if(aylikfark <0){
		aylikfark +=12;
		yillikfark--; 
	}
	int toplamgun = gunlukfark+aylikfark*30;
   	
   	return toplamgun;
}
int mutlak(int sayi){
	if(sayi<0){
		sayi = sayi*(-1);
	}
	return sayi;
}

int main(int argc, char *argv[]) {
	system("color F2");

	int secim =-1;
	
	while(secim!=0){
	system("clear");
	menu();	
	printf("\nSeciminizi yapiniz\n");
	scanf("%d",&secim);
	int secim2 =0;	
	switch(secim){
		case 1: 
			
			printf("\n1-Ogrenci Ekle\n");
			printf("2-Firma Ekle\n");
			printf("Seciminiz: \n");
			scanf("%d",&secim2);
			if(secim2 == 1){
				OgrenciEkle();
				printf("\n Ogrenci eklendi");
				system("Pause");
			}
			else if(secim2 ==2){
				FirmaEkleme();
				printf("\n Firma eklendi");
				system("Pause");
			}
			else {
				printf("Hatali secim");
				system("Pause");
			}
			break;
		case 2:
				printf("\n1-Ogrencileri Listele\n");
			printf("2-Firmalari Listele\n");
			printf("Seciminiz: \n");
			scanf("%d",&secim2);
			if(secim2 == 1){
				OgrencileriListele();
				system("Pause");
			}
			else if(secim2 ==2){
				FirmaListele();
				system("Pause");
			}
			else {
				printf("Hatali secim");
				system("Pause");
			}
			break;
		case 3:
				printf("\n1-Ogrenci Bilgi Guncelle\n");
			printf("2-Firma Bilgi Guncelle\n");
			printf("Seciminiz: \n");
			scanf("%d",&secim2);
			if(secim2 == 1){
				OgrenciDuzenle();
				printf("Ogrenci duzenlendi");
				system("Pause");
			}
			else if(secim2 ==2){
				FirmaDuzenle();
				printf("Firma duzenlendi");
				system("Pause");
			}
			else {
				printf("Hatali secim");
				system("Pause");
			}
			break;
		case 4:
			printf("\n1-Ogrenci Sil\n");
			printf("2-Firma Sil\n");
			printf("Seciminiz: \n");
			scanf("%d",&secim2);
			if(secim2 == 1){
				OgrenciSil();
				printf("Ogrenci silindi");
				system("Pause");
			}
			else if(secim2 ==2){
				FirmaSilme();
				printf("Firma silindi");
				system("Pause");
			}
			else {
				printf("Hatali secim");
				system("Pause");
			}
			break;
		case 5:
				printf("\n1-Staji Tamamlanmis Olanlar\n");
			printf("2-Staji Tamamlanmamis Olanlar\n");
			printf("Seciminiz: \n");
			scanf("%d",&secim2);
			if(secim2 == 1){
				TamamlanmisStaj();
				system("Pause");
			}
			else if(secim2 ==2){
				TamamlanmamisStaj();
				system("Pause");
			}
			else {
				printf("Hatali secim");
				system("Pause");
			}
			break;
		case 6: 
			StajEkle();
			printf("Staj eklendi");
				system("Pause");
			break;	
		case 0:
			printf("\t\tIyi gunler dileriz..");
					return 0;
			break;
		default:
			printf("Hatali secim");
			break;	
	}
	
	}
	
	return 0;
}
